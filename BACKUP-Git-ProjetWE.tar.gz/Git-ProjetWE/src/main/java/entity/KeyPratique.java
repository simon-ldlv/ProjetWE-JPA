package entity;

import java.io.Serializable;

public class KeyPratique implements Serializable{
    Personne personne;
   
    Sport sport;
}