# ProjetWE-JPA

Prérequis : 

sudo apt install git-extras umlet


Accès PhpMyAdmin Simon : 

http://phpmyadmin2.istic.univ-rennes1.fr/
User : user_16002505
Password : hihihoho
